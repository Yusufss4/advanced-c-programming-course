#include <stdio.h>
#include <stdlib.h>

int count;
void display();

int main() {
    
	for(count=0;count<5;count++)
     	display();

    return 0;
}
